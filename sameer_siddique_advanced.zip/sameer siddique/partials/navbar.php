<?php
if(!isset($_SESSION)) session_start();
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container">
    <a class="navbar-brand" href="/sameer_siddique/dashboard.php">SMS</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="nav">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link" href="/sameer_siddique/students/list.php">Students</a></li>
      </ul>
      <ul class="navbar-nav">
        <?php if(isset($_SESSION['user_name'])): ?>
          <li class="nav-item"><a class="nav-link" href="#"><?= esc($_SESSION['user_name']) ?></a></li>
          <li class="nav-item"><a class="nav-link" href="/sameer_siddique/auth/logout.php">Logout</a></li>
        <?php else: ?>
          <li class="nav-item"><a class="nav-link" href="/sameer_siddique/auth/login.php">Login</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>
